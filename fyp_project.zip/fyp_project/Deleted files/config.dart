const url = 'http://172.16.188.92:8080/';
const registration = "${url}registration";