import 'package:flutter/material.dart';

class HomePsych extends StatefulWidget {
  const HomePsych({super.key});

  @override
  State<HomePsych> createState() => _HomePsychState();
}

class _HomePsychState extends State<HomePsych> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('This is Psycologist Home screen'),
    );
  }
}
