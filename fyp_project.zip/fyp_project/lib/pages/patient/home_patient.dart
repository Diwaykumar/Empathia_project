import 'package:flutter/material.dart';
import 'package:fyp_project/common/widgets/custom_button.dart';

class HomePatient extends StatefulWidget {
  const HomePatient({super.key});

  @override
  State<HomePatient> createState() => _HomePatientState();
}

class _HomePatientState extends State<HomePatient> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              const SizedBox(
                height: 150,
              ),
              const Text(
                'Take a Mental Health Test',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 50),
              const Text(
                'Learn to handle mental illness.\nBecome more focused. Achieve your goals.',
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 18),
              CustomButton(
                text: 'Take Quiz',
                onTap: () {
                  Navigator.of(context, rootNavigator: true).pushNamed('/quiz');
                },
              ),
              const SizedBox(height: 10),
              CustomButton(
                text: 'Skip',
                onTap: () {
                  // Resend OTP functionality here
                },
              ),
              const SizedBox(height: 15),
              const Image(image: AssetImage('quiz.png'), fit: BoxFit.cover),
            ],
          ),
        ),
      ),
    );
  }
}

// bottomNavigationBar: Container(
//   color: Colors.white10,
//   child: Padding(
//     padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20),
//     child: GNav(
//       backgroundColor: Colors.white10,
//       color: Colors.black,
//       activeColor: Colors.white,
//       tabBackgroundColor: Colors.cyan.shade700,
//       gap: 8,
//       onTabChange: (index) {
//         (index);
//       },
//       padding: const EdgeInsets.all(16.0),
//       tabs: const [
//         GButton(icon: Icons.home, text: 'Home'),
//         GButton(icon: Icons.article_outlined, text: 'Article'),
//         GButton(icon: Icons.groups, text: 'Community'),
//         GButton(icon: Icons.settings, text: 'Setting'),
//       ],
//     ),
//   ),
// ),
